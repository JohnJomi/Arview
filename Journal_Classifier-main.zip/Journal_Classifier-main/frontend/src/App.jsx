import React, { useState, useEffect } from "react";
import Header from "./components/Header";
import DropZone from "./components/DropZone";
import ClassificationResult from "./components/ClassificationResult";
import SpecterEmbeddingMap from "./components/SpecterEmbeddingMap";
import MetadataViewer from "./components/MetadataViewer";
import BatchClassifier from "./components/BatchClassifier";
import ReviewQueueView from "./components/ReviewQueueView";
import PipelineDiagram from "./components/PipelineDiagram";
import HumanReviewModal from "./components/HumanReviewModal";
import ModelConnectGuide from "./components/ModelConnectGuide";
import { checkBackendHealth, classifyPaper } from "./services/api";
import { SAMPLE_PAPERS } from "./data/samplePapers";

export default function App() {
  const [activeTab, setActiveTab] = useState("single");
  const [currentPaper, setCurrentPaper] = useState(SAMPLE_PAPERS[0]);
  const [isClassifying, setIsClassifying] = useState(false);
  const [progressStep, setProgressStep] = useState(0);
  const [backendStatus, setBackendStatus] = useState({ online: false });
  const [showModelGuide, setShowModelGuide] = useState(false);
  const [reviewModalPaper, setReviewModalPaper] = useState(null);
  const [reviewCount, setReviewCount] = useState(0);

  // Theme Management (Light / Dark)
  const [theme, setTheme] = useState(() => {
    return localStorage.getItem("journal_theme") || "light";
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === "dark") {
      root.classList.add("dark");
      root.classList.remove("light");
    } else {
      root.classList.add("light");
      root.classList.remove("dark");
    }
    localStorage.setItem("journal_theme", theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => (prev === "dark" ? "light" : "dark"));
  };

  useEffect(() => {
    let isMounted = true;
    const check = async () => {
      const status = await checkBackendHealth();
      if (isMounted) setBackendStatus(status);
    };
    check();
    const interval = setInterval(check, 10000);

    const saved = JSON.parse(localStorage.getItem("journal_classifier_reviews") || "[]");
    setReviewCount(saved.length);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  const handleClassify = async ({ file, sampleId, text, title }) => {
    setIsClassifying(true);
    setProgressStep(0);

    const stepTimer1 = setTimeout(() => setProgressStep(1), 200);
    const stepTimer2 = setTimeout(() => setProgressStep(2), 450);
    const stepTimer3 = setTimeout(() => setProgressStep(3), 700);

    try {
      const result = await classifyPaper({ file, sampleId, text, title });
      setCurrentPaper(result);
      setActiveTab("single");
    } catch (err) {
      console.error("Classification error:", err);
    } finally {
      clearTimeout(stepTimer1);
      clearTimeout(stepTimer2);
      clearTimeout(stepTimer3);
      setIsClassifying(false);
      setProgressStep(0);
    }
  };

  const handleReviewSubmitted = () => {
    const saved = JSON.parse(localStorage.getItem("journal_classifier_reviews") || "[]");
    setReviewCount(saved.length);
  };

  return (
    <div 
      className="min-h-screen font-sans flex flex-col antialiased selection:bg-red-600 selection:text-white"
      style={{ backgroundColor: "var(--bg)", color: "var(--text)" }}
    >
      {/* Header with Top-Right Light/Dark Toggle */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        backendStatus={backendStatus}
        reviewCount={reviewCount}
        onOpenModelGuide={() => setShowModelGuide(true)}
        theme={theme}
        onToggleTheme={toggleTheme}
      />

      {/* Hero Typographic Section */}
      <section className="border-b-2" style={{ borderColor: "var(--rule)", backgroundColor: "var(--bg)" }}>
        <div className="max-w-[78rem] mx-auto px-6 py-8 sm:py-12">
          <div className="grid grid-cols-12 gap-6 items-end">
            <div className="col-span-12 lg:col-span-8 space-y-2">
              <span className="eyebrow">
                AI RESEARCH CLASSIFICATION PLATFORM // READY FOR CLIENT USE
              </span>
              <h1 style={{ color: "var(--text)" }}>
                SPECTER<span className="text-red-600">.</span>NET
              </h1>
              <p className="lead max-w-2xl mt-2" style={{ color: "var(--text-muted)" }}>
                Upload scientific research papers to automatically identify their domain, compute honest confidence scores, and export categorized data.
              </p>
            </div>

            <div 
              className="col-span-12 lg:col-span-4 border-t lg:border-t-0 lg:border-l lg:pl-6 pt-4 lg:pt-0 font-mono text-xs space-y-2"
              style={{ borderColor: "var(--rule)", color: "var(--text-muted)" }}
            >
              <div className="flex justify-between border-b pb-1" style={{ borderColor: "var(--rule)" }}>
                <span>INTERFACE DESIGN:</span>
                <span className="font-bold" style={{ color: "var(--text)" }}>SWISS MODERNISM 2.0</span>
              </div>
              <div className="flex justify-between border-b pb-1" style={{ borderColor: "var(--rule)" }}>
                <span>CURRENT THEME:</span>
                <span className="font-bold uppercase text-red-600">{theme} MODE</span>
              </div>
              <div className="flex justify-between border-b pb-1" style={{ borderColor: "var(--rule)" }}>
                <span>FASTAPI BACKEND:</span>
                <span className="font-bold" style={{ color: backendStatus?.online ? "var(--text)" : "var(--red)" }}>
                  {backendStatus?.online ? "CONNECTED (:8000)" : "DEMO RUNTIME"}
                </span>
              </div>
              <div className="flex justify-between">
                <span>CONFIDENCE ENGINE:</span>
                <span className="font-bold" style={{ color: "var(--text)" }}>CALIBRATED (T = 1.15)</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Grid Work Area */}
      <main className="flex-1 max-w-[78rem] w-full mx-auto px-6 py-8 space-y-10">
        {/* TAB 01: Single Paper Classifier */}
        {activeTab === "single" && (
          <div className="space-y-10">
            {/* Input & Drop Zone */}
            <DropZone
              onClassify={handleClassify}
              isClassifying={isClassifying}
              progressStep={progressStep}
            />

            {/* Results Section formatted on a 12-Column Grid */}
            {currentPaper && !isClassifying && (
              <div className="pt-6 border-t-2 space-y-8" style={{ borderColor: "var(--rule)" }}>
                <div className="flex items-center justify-between border-b-2 pb-2" style={{ borderColor: "var(--rule)" }}>
                  <span className="eyebrow text-xs">
                    PAPER CLASSIFICATION RESULTS // SUMMARY
                  </span>
                  <span className="font-mono text-xs uppercase" style={{ color: "var(--text-subtle)" }}>
                    ACTIVE PAPER ID: {currentPaper.id || "CURRENT-ACTIVE"}
                  </span>
                </div>

                {/* 12-Column Asymmetric Swiss Layout */}
                <div className="grid grid-cols-12 gap-8">
                  {/* Main Column (8 cols): Primary Classification + Metadata */}
                  <div className="col-span-12 lg:col-span-8 space-y-8">
                    <ClassificationResult
                      paper={currentPaper}
                      onOpenReviewModal={(p) => setReviewModalPaper(p)}
                    />
                    <MetadataViewer paper={currentPaper} />
                  </div>

                  {/* Aside Column (4 cols): Latent Projection Map */}
                  <div className="col-span-12 lg:col-span-4 space-y-8">
                    <SpecterEmbeddingMap paper={currentPaper} />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 02: Batch Ingestion */}
        {activeTab === "batch" && (
          <BatchClassifier
            onSelectPaperForDetail={(paper) => {
              setCurrentPaper(paper);
              setActiveTab("single");
            }}
          />
        )}

        {/* TAB 03: Human Review */}
        {activeTab === "review" && (
          <ReviewQueueView />
        )}

        {/* TAB 04: Architecture */}
        {activeTab === "pipeline" && (
          <PipelineDiagram
            onOpenModelGuide={() => setShowModelGuide(true)}
          />
        )}
      </main>

      {/* Hairline Rule Footer */}
      <footer className="border-t-2 py-6 text-xs font-mono" style={{ borderColor: "var(--rule)", backgroundColor: "var(--bg)" }}>
        <div className="max-w-[78rem] mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-3" style={{ color: "var(--text-muted)" }}>
            <span className="font-bold" style={{ color: "var(--text)" }}>SPECTER-NET 2.0</span>
            <span>//</span>
            <span>SWISS MODERNISM INTERNATIONAL STYLE</span>
            <span>//</span>
            <span>GRID ARCHITECTURE</span>
          </div>

          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowModelGuide(true)}
              className="font-bold uppercase transition-colors"
              style={{ color: "var(--text)" }}
            >
              MODEL INTEGRATION SPECIFICATION →
            </button>
          </div>
        </div>
      </footer>

      {/* Human Review Modal */}
      {reviewModalPaper && (
        <HumanReviewModal
          paper={reviewModalPaper}
          onClose={() => setReviewModalPaper(null)}
          onReviewSubmitted={handleReviewSubmitted}
        />
      )}

      {/* Developer Model Hook Guide Modal */}
      {showModelGuide && (
        <ModelConnectGuide onClose={() => setShowModelGuide(false)} />
      )}
    </div>
  );
}
