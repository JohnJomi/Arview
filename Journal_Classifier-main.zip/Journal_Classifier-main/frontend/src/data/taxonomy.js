export const DOMAINS = [
  {
    id: "cs",
    name: "Computer Science",
    code: "01",
    subcategories: [
      { id: "cs.AI", name: "Artificial Intelligence", description: "General AI, reasoning, knowledge representation" },
      { id: "cs.CL", name: "Computation and Language (NLP)", description: "Natural language processing, speech, parsing" },
      { id: "cs.CV", name: "Computer Vision and Pattern Recognition", description: "Image processing, video, 3D vision" },
      { id: "cs.LG", name: "Machine Learning", description: "Learning algorithms, deep neural nets, reinforcement learning" },
      { id: "cs.CR", name: "Cryptography and Security", description: "Network security, protocols, cryptographic primitives" },
      { id: "cs.DC", name: "Distributed & Cluster Computing", description: "Cloud systems, consensus, parallel architectures" },
      { id: "cs.RO", name: "Robotics", description: "Control, kinematics, autonomous navigation" },
      { id: "cs.NE", name: "Neural and Evolutionary Computing", description: "Genetic algorithms, neuromorphic architectures" }
    ]
  },
  {
    id: "math",
    name: "Mathematics",
    code: "02",
    subcategories: [
      { id: "math.ST", name: "Statistics Theory", description: "Mathematical statistics, asymptotic theory" },
      { id: "math.PR", name: "Probability", description: "Stochastic processes, random matrix theory" },
      { id: "math.OC", name: "Optimization and Control", description: "Convex optimization, dynamic programming" },
      { id: "math.NA", name: "Numerical Analysis", description: "Finite elements, error bounds, scientific computing" }
    ]
  },
  {
    id: "physics",
    name: "Physics",
    code: "03",
    subcategories: [
      { id: "quant-ph", name: "Quantum Physics", description: "Quantum computing, entanglement, quantum information" },
      { id: "cond-mat", name: "Condensed Matter", description: "Superconductivity, materials, topological insulators" },
      { id: "physics.soc-ph", name: "Physics and Society", description: "Complex networks, epidemic spreading" }
    ]
  },
  {
    id: "q-bio",
    name: "Quantitative Biology",
    code: "04",
    subcategories: [
      { id: "q-bio.GN", name: "Genomics", description: "Genome sequencing, variant effect, CRISPR analysis" },
      { id: "q-bio.BM", name: "Biomolecules", description: "Protein folding, structural biology, docking" },
      { id: "q-bio.NC", name: "Neurons and Cognition", description: "Computational neuroscience, synaptic plasticity" }
    ]
  },
  {
    id: "q-fin",
    name: "Quantitative Finance",
    code: "05",
    subcategories: [
      { id: "q-fin.PR", name: "Pricing of Securities", description: "Derivatives pricing, Black-Scholes, Greeks" },
      { id: "q-fin.RM", name: "Risk Management", description: "Value-at-Risk, stress testing, systemic risk" },
      { id: "q-fin.ST", name: "Statistical Finance", description: "High-frequency trading, market microstructure" }
    ]
  },
  {
    id: "stat",
    name: "Statistics",
    code: "06",
    subcategories: [
      { id: "stat.ML", name: "Machine Learning (Stat)", description: "Statistical learning theory, empirical Bayes" },
      { id: "stat.ME", name: "Methodology", description: "Experimental design, causal inference, imputation" }
    ]
  },
  {
    id: "eess",
    name: "Electrical Eng. & Systems",
    code: "07",
    subcategories: [
      { id: "eess.SP", name: "Signal Processing", description: "Audio, radar, wavelet transforms" },
      { id: "eess.SY", name: "Systems and Control", description: "Feedback loops, state space estimation" }
    ]
  }
];

export const ALL_SUBCATEGORIES = DOMAINS.flatMap(d => 
  d.subcategories.map(s => ({ ...s, domainId: d.id, domainName: d.name, domainCode: d.code }))
);

export const getCategoryById = (id) => {
  return ALL_SUBCATEGORIES.find(s => s.id === id) || {
    id,
    name: id,
    domainName: "Interdisciplinary",
    domainCode: "00",
    description: "Multi-domain research topic"
  };
};
