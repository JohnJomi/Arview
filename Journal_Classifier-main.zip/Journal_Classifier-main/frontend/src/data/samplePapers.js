export const SAMPLE_PAPERS = [
  {
    id: "sample-transformer",
    title: "Attention Is All You Need",
    authors: ["Ashish Vaswani", "Noam Shazeer", "Niki Parmar", "Jakob Uszkoreit", "Llion Jones", "Aidan N. Gomez", "Lukasz Kaiser", "Illia Polosukhin"],
    affiliations: ["Google Brain", "Google Research", "University of Toronto"],
    abstract: "The dominant sequence transduction models are based on complex recurrent or convolutional neural networks that include an encoder and a decoder. The best performing models also connect the encoder and decoder through an attention mechanism. We propose a new simple network architecture, the Transformer, based solely on attention mechanisms, dispensing with recurrence and convolutions entirely. Experiments on two machine translation tasks show these models to be superior in quality while being more parallelizable and requiring significantly less time to train.",
    keywords: ["Self-Attention", "Sequence-to-Sequence", "Transformer Architecture", "Multi-Head Attention", "BLEU Score", "Machine Translation"],
    venue: "NeurIPS 2017",
    year: 2017,
    doi: "10.48550/arXiv.1706.03762",
    pageCount: 15,
    wordCount: 5240,
    primaryCategory: "cs.CL",
    isLowConfidence: false,
    calibration: {
      temperature: 1.15,
      rawConfidence: 0.962,
      calibratedConfidence: 0.948,
      expectedCalibrationError: 0.018,
    },
    predictions: [
      { id: "cs.CL", score: 0.948, calibratedScore: 0.948, rank: 1 },
      { id: "cs.LG", score: 0.892, calibratedScore: 0.875, rank: 2 },
      { id: "cs.AI", score: 0.814, calibratedScore: 0.796, rank: 3 },
      { id: "stat.ML", score: 0.655, calibratedScore: 0.631, rank: 4 },
      { id: "math.OC", score: 0.124, calibratedScore: 0.108, rank: 5 }
    ],
    embeddingPreview: {
      dim: 768,
      norm: 1.0,
      pcaCoords: [-0.62, 0.48],
      topDimensions: [0.082, -0.141, 0.312, 0.045, -0.218, 0.119, 0.076, -0.198],
      nearestNeighbors: [
        { title: "BERT: Pre-training of Deep Bidirectional Transformers", similarity: 0.912, domain: "cs.CL" },
        { title: "RoBERTa: A Robustly Optimized BERT Pretraining Approach", similarity: 0.887, domain: "cs.CL" },
        { title: "Language Models are Few-Shot Learners (GPT-3)", similarity: 0.864, domain: "cs.CL" }
      ]
    }
  },
  {
    id: "sample-resnet",
    title: "Deep Residual Learning for Image Recognition",
    authors: ["Kaiming He", "Xiangyu Zhang", "Shaoqing Ren", "Jian Sun"],
    affiliations: ["Microsoft Research"],
    abstract: "Deeper neural networks are more difficult to train. We present a residual learning framework to ease the training of networks that are substantially deeper than those used previously. We explicitly reformulate the layers as learning residual functions with reference to the layer inputs, instead of learning unreferenced functions. We provide comprehensive empirical evidence showing that these networks are easier to optimize and gain accuracy from considerably increased depth. On the ImageNet dataset we evaluate residual nets with a depth of up to 152 layers—8x deeper than VGG nets.",
    keywords: ["Residual Learning", "Convolutional Neural Networks", "ImageNet", "Degradation Problem", "Skip Connections", "Object Detection"],
    venue: "IEEE CVPR 2016 (Best Paper Award)",
    year: 2016,
    doi: "10.1109/CVPR.2016.90",
    pageCount: 12,
    wordCount: 6180,
    primaryCategory: "cs.CV",
    isLowConfidence: false,
    calibration: {
      temperature: 1.15,
      rawConfidence: 0.985,
      calibratedConfidence: 0.971,
      expectedCalibrationError: 0.015,
    },
    predictions: [
      { id: "cs.CV", score: 0.985, calibratedScore: 0.971, rank: 1 },
      { id: "cs.LG", score: 0.912, calibratedScore: 0.894, rank: 2 },
      { id: "cs.AI", score: 0.778, calibratedScore: 0.755, rank: 3 },
      { id: "stat.ML", score: 0.590, calibratedScore: 0.564, rank: 4 },
      { id: "eess.SP", score: 0.280, calibratedScore: 0.252, rank: 5 }
    ],
    embeddingPreview: {
      dim: 768,
      norm: 1.0,
      pcaCoords: [-0.45, -0.68],
      topDimensions: [-0.115, 0.245, -0.089, 0.176, 0.334, -0.052, 0.142, 0.088],
      nearestNeighbors: [
        { title: "Very Deep Convolutional Networks for Large-Scale Image Recognition (VGG)", similarity: 0.895, domain: "cs.CV" },
        { title: "Going Deeper with Convolutions (GoogLeNet)", similarity: 0.874, domain: "cs.CV" },
        { title: "Aggregated Residual Transformations for Deep Neural Networks (ResNeXt)", similarity: 0.923, domain: "cs.CV" }
      ]
    }
  },
  {
    id: "sample-quantum",
    title: "Quantum Computational Supremacy Using a Programmable Superconducting Processor",
    authors: ["Frank Arute", "Kunal Arya", "Ryan Babbush", "Dave Bacon", "John M. Martinis et al."],
    affiliations: ["Google AI Quantum", "UC Santa Barbara"],
    abstract: "The promise of quantum computers is that certain computational tasks might be executed exponentially faster on a quantum processor than on a classical computer. A fundamental milestone is demonstrating quantum supremacy: a computational task performed on a quantum processor that is infeasible for a classical supercomputer. We use a processor with 54 superconducting transmon qubits named Sycamore to sample the output of pseudo-random quantum circuits.",
    keywords: ["Quantum Supremacy", "Superconducting Qubits", "Cross-Entropy Benchmarking", "Transmon", "Quantum Circuit Simulation"],
    venue: "Nature 2019",
    year: 2019,
    doi: "10.1038/s41586-019-1666-5",
    pageCount: 16,
    wordCount: 7420,
    primaryCategory: "quant-ph",
    isLowConfidence: false,
    calibration: {
      temperature: 1.15,
      rawConfidence: 0.978,
      calibratedConfidence: 0.965,
      expectedCalibrationError: 0.012,
    },
    predictions: [
      { id: "quant-ph", score: 0.978, calibratedScore: 0.965, rank: 1 },
      { id: "cond-mat", score: 0.742, calibratedScore: 0.718, rank: 2 },
      { id: "cs.DC", score: 0.421, calibratedScore: 0.395, rank: 3 },
      { id: "math.PR", score: 0.285, calibratedScore: 0.260, rank: 4 }
    ],
    embeddingPreview: {
      dim: 768,
      norm: 1.0,
      pcaCoords: [0.72, 0.35],
      topDimensions: [0.221, -0.098, -0.174, 0.298, -0.042, 0.165, -0.231, 0.054],
      nearestNeighbors: [
        { title: "Quantum error correction with superconducting qubits", similarity: 0.884, domain: "quant-ph" },
        { title: "Simulating quantum systems on a transmon lattice", similarity: 0.869, domain: "quant-ph" }
      ]
    }
  },
  {
    id: "sample-crispr",
    title: "Structural Basis of Cas9 and RNA-Guided DNA Cleavage",
    authors: ["Martin Jinek", "Krzysztof Chylinski", "Ines Fonfara", "Michael Hauer", "Jennifer A. Doudna", "Emmanuelle Charpentier"],
    affiliations: ["UC Berkeley", "University of Vienna", "Umeå University"],
    abstract: "Clustered regularly interspaced short palindromic repeats (CRISPR)/CRISPR-associated (Cas) systems provide bacteria and archaea with adaptive immunity against viruses and plasmids. Here we show that the Cas9 endonuclease can be programmed with single guide RNAs to target and cleave specific double-stranded DNA sequences in vitro. Structural and biochemical assays reveal that conformational rearrangements trigger the HNH and RuvC nuclease domains.",
    keywords: ["CRISPR-Cas9", "Endonuclease", "Guide RNA", "Targeted Cleavage", "Genome Editing", "R-loop Structure"],
    venue: "Science 2012",
    year: 2012,
    doi: "10.1126/science.1225829",
    pageCount: 9,
    wordCount: 4500,
    primaryCategory: "q-bio.BM",
    isLowConfidence: false,
    calibration: {
      temperature: 1.15,
      rawConfidence: 0.954,
      calibratedConfidence: 0.941,
      expectedCalibrationError: 0.016,
    },
    predictions: [
      { id: "q-bio.BM", score: 0.954, calibratedScore: 0.941, rank: 1 },
      { id: "q-bio.GN", score: 0.885, calibratedScore: 0.862, rank: 2 },
      { id: "q-bio.NC", score: 0.145, calibratedScore: 0.128, rank: 3 }
    ],
    embeddingPreview: {
      dim: 768,
      norm: 1.0,
      pcaCoords: [0.65, -0.58],
      topDimensions: [-0.045, -0.321, 0.118, -0.092, 0.187, 0.224, 0.038, -0.176],
      nearestNeighbors: [
        { title: "RNA-programmed genome editing in human cells", similarity: 0.925, domain: "q-bio.GN" },
        { title: "Crystal structure of Cas9 in complex with guide RNA and target DNA", similarity: 0.941, domain: "q-bio.BM" }
      ]
    }
  },
  {
    id: "sample-ambiguous-interdisciplinary",
    title: "Stochastic Deep Reinforcement Learning for High-Frequency Limit Order Book Liquidity Provision",
    authors: ["Alexander Chen", "Elena Rostova", "Marcus Vance"],
    affiliations: ["Oxford-Man Institute of Quantitative Finance", "Turing Institute"],
    abstract: "We formulate high-frequency automated market making in equity and cryptocurrency order books as a continuous action-space Markov Decision Process. Employing soft actor-critic algorithms coupled with jump-diffusion stochastic volatility jump processes, we investigate whether deep neural agents can avoid adverse selection. Empirical backtests on NASDAQ tick-by-tick message feeds demonstrate competitive Sharpe ratios, yet exhibit significant volatility clustering during regime changes.",
    keywords: ["High-Frequency Trading", "Limit Order Books", "Deep Reinforcement Learning", "Market Making", "Adverse Selection", "Jump Diffusion"],
    venue: "Journal of Financial Econometrics & AI 2024 (Preprint)",
    year: 2024,
    doi: "10.48550/arXiv.2403.99821",
    pageCount: 22,
    wordCount: 9800,
    primaryCategory: "q-fin.ST",
    isLowConfidence: true, // TRIGGERS HUMAN REVIEW DASHBOARD!
    calibration: {
      temperature: 1.25,
      rawConfidence: 0.684,
      calibratedConfidence: 0.628,
      expectedCalibrationError: 0.062,
    },
    predictions: [
      { id: "q-fin.ST", score: 0.684, calibratedScore: 0.628, rank: 1 },
      { id: "cs.LG", score: 0.652, calibratedScore: 0.598, rank: 2 },
      { id: "q-fin.PR", score: 0.589, calibratedScore: 0.534, rank: 3 },
      { id: "math.PR", score: 0.441, calibratedScore: 0.405, rank: 4 },
      { id: "stat.ML", score: 0.395, calibratedScore: 0.362, rank: 5 }
    ],
    embeddingPreview: {
      dim: 768,
      norm: 1.0,
      pcaCoords: [0.15, 0.12],
      topDimensions: [0.102, 0.088, -0.145, 0.198, 0.054, -0.112, 0.177, 0.034],
      nearestNeighbors: [
        { title: "Deep Reinforcement Learning in Quantitative Asset Management", similarity: 0.812, domain: "q-fin.PR" },
        { title: "Deep Hedging with Stochastic Volatility", similarity: 0.795, domain: "q-fin.PR" }
      ]
    }
  }
];
