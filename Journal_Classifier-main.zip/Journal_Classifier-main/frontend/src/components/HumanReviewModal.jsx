import React, { useState } from "react";
import { ALL_SUBCATEGORIES, getCategoryById } from "../data/taxonomy";
import { submitHumanReview } from "../services/api";

export default function HumanReviewModal({ paper, onClose, onReviewSubmitted }) {
  if (!paper) return null;

  const [selectedDomain, setSelectedDomain] = useState(paper.primaryCategory);
  const [secondaryTags, setSecondaryTags] = useState(
    paper.predictions?.slice(1, 3).map(p => p.id) || []
  );
  const [reviewerNotes, setReviewerNotes] = useState("");
  const [verdict, setVerdict] = useState("approved_with_corrections");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const toggleSecondary = (catId) => {
    if (secondaryTags.includes(catId)) {
      setSecondaryTags(secondaryTags.filter(id => id !== catId));
    } else {
      if (secondaryTags.length < 4) {
        setSecondaryTags([...secondaryTags, catId]);
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    const reviewPayload = {
      paperId: paper.id,
      title: paper.title,
      modelPredictedCategory: paper.primaryCategory,
      modelConfidence: paper.predictions?.[0]?.calibratedScore || 0.65,
      humanValidatedCategory: selectedDomain,
      secondaryCategories: secondaryTags,
      verdict,
      reviewerNotes,
      reviewedAt: new Date().toISOString(),
      status: "labeled_for_retraining"
    };

    await submitHumanReview(reviewPayload);
    setIsSubmitting(false);
    onReviewSubmitted(reviewPayload);
    onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div 
        className="border-2 max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6"
        style={{ borderColor: "var(--rule-strong)", backgroundColor: "var(--bg)" }}
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b pb-4" style={{ borderColor: "var(--rule)" }}>
          <div>
            <span className="eyebrow" id="modal-title">EASY CATEGORY VERIFIER // REVIEW</span>
            <h3 className="text-xl font-bold uppercase tracking-tight mt-1" style={{ color: "var(--text)" }}>
              Confirm or Correct Classification
            </h3>
            <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>
              Choose whether the model got it right, or select the correct field below.
            </p>
          </div>

          <button
            onClick={onClose}
            aria-label="Close dialog"
            className="w-8 h-8 border flex items-center justify-center font-mono text-sm font-bold transition-colors cursor-pointer"
            style={{ borderColor: "var(--rule-strong)", color: "var(--text)" }}
          >
            ✕
          </button>
        </div>

        {/* Paper Reference Box */}
        <div 
          className="border p-4 space-y-2"
          style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}
        >
          <div className="flex items-center justify-between font-mono text-xs">
            <span className="font-bold uppercase line-clamp-1" style={{ color: "var(--text)" }}>{paper.title}</span>
            <span className="text-red-600 font-bold shrink-0 ml-2">
              AI PREDICTION: {paper.primaryCategory} ({Math.round((paper.predictions?.[0]?.calibratedScore || 0.65) * 100)}%)
            </span>
          </div>
          <p className="text-xs line-clamp-2" style={{ color: "var(--text-muted)" }}>
            "{paper.abstract}"
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Decision Buttons */}
          <div>
            <label className="eyebrow mb-2">
              WHAT WOULD YOU LIKE TO DO?
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {[
                { id: "confirm_predicted", label: "CONFIRM PREDICTION", desc: "The model is correct" },
                { id: "approved_with_corrections", label: "CHANGE CATEGORY", desc: "Pick the correct category" },
                { id: "flag_out_of_distribution", label: "DIFFERENT TOPIC", desc: "Brand new field or unlisted" },
              ].map(opt => (
                <button
                  type="button"
                  key={opt.id}
                  onClick={() => setVerdict(opt.id)}
                  className="p-3 border text-left transition-colors cursor-pointer"
                  style={{
                    borderColor: verdict === opt.id ? "var(--rule-strong)" : "var(--rule)",
                    backgroundColor: verdict === opt.id ? "var(--rule-strong)" : "var(--surface)",
                    color: verdict === opt.id ? "var(--bg)" : "var(--text)"
                  }}
                >
                  <span className="text-xs font-bold uppercase block">{opt.label}</span>
                  <span className="text-[10px] block mt-1 opacity-80">
                    {opt.desc}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Primary Domain Target */}
          {verdict !== "flag_out_of_distribution" && (
            <div>
              <label className="eyebrow mb-1">
                SELECT THE CORRECT MAIN CATEGORY:
              </label>
              <select
                value={selectedDomain}
                onChange={(e) => setSelectedDomain(e.target.value)}
                className="w-full border p-3 text-xs font-mono focus:border-red-600"
                style={{ 
                  backgroundColor: "var(--surface)", 
                  borderColor: "var(--rule-strong)", 
                  color: "var(--text)" 
                }}
              >
                {ALL_SUBCATEGORIES.map(cat => (
                  <option key={cat.id} value={cat.id}>
                    [{cat.id}] {cat.name} — ({cat.domainName})
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Secondary Tags */}
          {verdict !== "flag_out_of_distribution" && (
            <div>
              <label className="eyebrow mb-1">
                OPTIONAL: TAG OTHER RELATED FIELDS (CLICK TO TOGGLE):
              </label>
              <div 
                className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-3 border"
                style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}
              >
                {ALL_SUBCATEGORIES.filter(c => c.id !== selectedDomain).map(cat => {
                  const isChecked = secondaryTags.includes(cat.id);
                  return (
                    <button
                      type="button"
                      key={cat.id}
                      onClick={() => toggleSecondary(cat.id)}
                      className="text-xs font-mono font-bold px-2 py-1 border transition-colors cursor-pointer"
                      style={{
                        borderColor: isChecked ? "var(--rule-strong)" : "var(--rule)",
                        backgroundColor: isChecked ? "var(--rule-strong)" : "var(--surface-card)",
                        color: isChecked ? "var(--bg)" : "var(--text)"
                      }}
                    >
                      {isChecked ? `[✓] ${cat.id}` : cat.id}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Reviewer remarks */}
          <div>
            <label className="eyebrow mb-1">
              OPTIONAL NOTES FOR THE TEAM:
            </label>
            <textarea
              rows={2}
              placeholder="e.g. This paper introduces a new algorithm bridging computer science and genetics."
              value={reviewerNotes}
              onChange={(e) => setReviewerNotes(e.target.value)}
              className="w-full border p-3 text-xs font-sans focus:border-red-600"
              style={{ 
                backgroundColor: "var(--surface)", 
                borderColor: "var(--rule)", 
                color: "var(--text)" 
              }}
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 pt-3 border-t" style={{ borderColor: "var(--rule)" }}>
            <button
              type="button"
              onClick={onClose}
              className="button button--sm button--outline"
            >
              CANCEL
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="button button--sm"
            >
              {isSubmitting ? "SAVING..." : "SAVE VERIFICATION →"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
