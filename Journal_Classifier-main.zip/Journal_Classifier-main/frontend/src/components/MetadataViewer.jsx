import React from "react";

export default function MetadataViewer({ paper }) {
  if (!paper) return null;

  return (
    <section 
      className="border-2 p-6 sm:p-8 space-y-6"
      style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface-card)" }}
      aria-labelledby="metadata-heading"
    >
      <div className="flex flex-col sm:flex-row sm:items-end justify-between border-b-2 pb-3 gap-2" style={{ borderColor: "var(--rule)" }}>
        <div>
          <span className="eyebrow" id="metadata-heading">DOCUMENT SUMMARY // EXTRACTED INFORMATION</span>
          <h3 className="text-xl font-bold uppercase tracking-tight mt-1" style={{ color: "var(--text)" }}>
            Extracted Paper Details &amp; Abstract
          </h3>
        </div>
        <span className="font-mono text-xs uppercase font-bold text-[#FF0000]">
          AUTO-EXTRACTED VIA PYMUPDF
        </span>
      </div>

      {/* Title & Authors */}
      <div className="space-y-3">
        <h4 className="text-2xl font-black uppercase tracking-tight leading-tight" style={{ color: "var(--text)" }}>
          {paper.title}
        </h4>

        {/* Authors with Stark Borders */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-mono">
          <span className="uppercase font-bold" style={{ color: "var(--text-subtle)" }}>AUTHORS:</span>
          {paper.authors?.map((author, idx) => (
            <span 
              key={idx} 
              className="border-2 px-2.5 py-0.5 font-black uppercase"
              style={{ 
                borderColor: "var(--rule)", 
                backgroundColor: "var(--surface)", 
                color: "var(--text)" 
              }}
            >
              {author}
            </span>
          ))}
        </div>

        {paper.affiliations && paper.affiliations.length > 0 && (
          <div className="text-xs font-mono font-medium" style={{ color: "var(--text-muted)" }}>
            AFFILIATION: {paper.affiliations.join(" // ")}
          </div>
        )}
      </div>

      {/* 4-Column Spec Sheet with Stark Borders */}
      <div className="grid grid-cols-2 sm:grid-cols-4 border-2 font-mono text-xs" style={{ borderColor: "var(--rule)" }}>
        <div className="p-3 border-r-2 border-b-2 sm:border-b-0" style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}>
          <span className="text-[10px] uppercase font-bold block" style={{ color: "var(--text-subtle)" }}>01 / JOURNAL / VENUE</span>
          <span className="font-black uppercase block truncate mt-1" style={{ color: "var(--text)" }}>
            {paper.venue || "ARXIV PREPRINT"}
          </span>
        </div>

        <div className="p-3 border-b-2 sm:border-b-0 sm:border-r-2" style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}>
          <span className="text-[10px] uppercase font-bold block" style={{ color: "var(--text-subtle)" }}>02 / PUBLICATION YEAR</span>
          <span className="font-black uppercase block mt-1" style={{ color: "var(--text)" }}>
            {paper.year || 2024}
          </span>
        </div>

        <div className="p-3 border-r-2" style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}>
          <span className="text-[10px] uppercase font-bold block" style={{ color: "var(--text-subtle)" }}>03 / IDENTIFIER (DOI)</span>
          <span className="font-black uppercase block truncate mt-1" style={{ color: "var(--text)" }}>
            {paper.doi || "10.48550/ARXIV"}
          </span>
        </div>

        <div className="p-3" style={{ backgroundColor: "var(--surface)" }}>
          <span className="text-[10px] uppercase font-bold block" style={{ color: "var(--text-subtle)" }}>04 / DOCUMENT LENGTH</span>
          <span className="font-black uppercase block mt-1" style={{ color: "var(--text)" }}>
            {paper.pageCount || 12} PGS // {paper.wordCount || 5000} WORDS
          </span>
        </div>
      </div>

      {/* Abstract with Stark Border */}
      <div className="space-y-2">
        <span className="eyebrow text-[10px]">
          PAPER ABSTRACT TEXT
        </span>
        <div 
          className="p-5 border-2 text-sm leading-relaxed font-sans"
          style={{ 
            borderColor: "var(--rule)", 
            backgroundColor: "var(--surface)", 
            color: "var(--text)" 
          }}
        >
          {paper.abstract}
        </div>
      </div>

      {/* Keywords with Stark Borders & Red Hover */}
      {paper.keywords && paper.keywords.length > 0 && (
        <div className="space-y-2 pt-1">
          <span className="eyebrow text-[10px]">
            EXTRACTED SCIENTIFIC DESCRIPTORS
          </span>
          <div className="flex flex-wrap gap-2">
            {paper.keywords.map((kw, i) => (
              <span
                key={i}
                className="text-xs font-mono font-bold uppercase px-3 py-1 border-2 transition-all cursor-default hover:border-[#FF0000] hover:text-[#FF0000]"
                style={{ 
                  borderColor: "var(--rule)", 
                  backgroundColor: "var(--surface-card)", 
                  color: "var(--text)" 
                }}
              >
                {kw}
              </span>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
