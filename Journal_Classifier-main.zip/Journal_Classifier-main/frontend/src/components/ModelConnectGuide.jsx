import React, { useState } from "react";

export default function ModelConnectGuide({ onClose }) {
  const [copiedIndex, setCopiedIndex] = useState(null);

  const copyToClipboard = (text, index) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const pythonSnippet = `# backend/model_service.py
import joblib
import numpy as np

class DomainClassifierService:
    def __init__(self):
        # 1. Load your trained model artifact here:
        # e.g., self.model = joblib.load("models/classifier_xgboost.joblib")
        # Or PyTorch: self.model = torch.load("models/mlp_classifier.pt")
        self.model = None

    def predict(self, embedding_768d: np.ndarray, text: str = ""):
        """
        Receives 768-dimensional SPECTER2 numerical vector
        Returns multi-label domain probabilities
        """
        if self.model is not None:
            # Inference using your real trained model
            probabilities = self.model.predict_proba([embedding_768d])[0]
            return probabilities
            
        # Fallback calibrated predictions while model is training
        return self._compute_heuristics(embedding_768d, text)`;

  const terminalCmd = `cd backend
pip install -r requirements.txt
python main.py`;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="guide-title"
    >
      <div 
        className="border-2 max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6"
        style={{ borderColor: "var(--rule-strong)", backgroundColor: "var(--bg)" }}
      >
        {/* Header */}
        <div className="flex items-start justify-between border-b pb-4" style={{ borderColor: "var(--rule)" }}>
          <div>
            <span className="eyebrow" id="guide-title">QUICK DEVELOPER GUIDE // READY FOR MODEL</span>
            <h3 className="text-xl font-bold uppercase tracking-tight mt-1" style={{ color: "var(--text)" }}>
              How to Connect Your Trained Model
            </h3>
            <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>
              Everything in the frontend and backend is already wired up. You only need to plug in your model file.
            </p>
          </div>

          <button
            onClick={onClose}
            aria-label="Close dialog"
            className="w-8 h-8 border flex items-center justify-center font-mono text-sm font-bold transition-colors cursor-pointer"
            style={{ borderColor: "var(--rule-strong)", color: "var(--text)" }}
          >
            ✕
          </button>
        </div>

        {/* 3 Simple Steps */}
        <div className="space-y-3">
          <span className="eyebrow text-[10px]">3-STEP SETUP CHECKLIST</span>

          <div className="grid grid-cols-1 gap-2 font-sans text-xs">
            <div 
              className="p-3 border flex items-start space-x-3"
              style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}
            >
              <span 
                className="font-mono font-bold text-xs px-2 py-0.5 shrink-0"
                style={{ backgroundColor: "var(--rule-strong)", color: "var(--bg)" }}
              >
                01
              </span>
              <div>
                <span className="font-bold uppercase block" style={{ color: "var(--text)" }}>Save Trained Weights</span>
                <p className="mt-0.5" style={{ color: "var(--text-muted)" }}>
                  Save your trained Logistic Regression, PyTorch MLP, or XGBoost model as a file (e.g. <code className="font-mono font-bold">models/classifier.joblib</code>).
                </p>
              </div>
            </div>

            <div 
              className="p-3 border flex items-start space-x-3"
              style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}
            >
              <span 
                className="font-mono font-bold text-xs px-2 py-0.5 shrink-0"
                style={{ backgroundColor: "var(--rule-strong)", color: "var(--bg)" }}
              >
                02
              </span>
              <div>
                <span className="font-bold uppercase block" style={{ color: "var(--text)" }}>Paste One Line in backend/model_service.py</span>
                <p className="mt-0.5" style={{ color: "var(--text-muted)" }}>
                  Open <code className="font-mono font-bold">backend/model_service.py</code> and load your model in <code className="font-mono font-bold">load_model()</code>. PDF extraction and UI communication are already finished.
                </p>
              </div>
            </div>

            <div 
              className="p-3 border flex items-start space-x-3"
              style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}
            >
              <span 
                className="font-mono font-bold text-xs px-2 py-0.5 shrink-0"
                style={{ backgroundColor: "var(--rule-strong)", color: "var(--bg)" }}
              >
                03
              </span>
              <div>
                <span className="font-bold uppercase block" style={{ color: "var(--text)" }}>Start Server &amp; Test</span>
                <p className="mt-0.5" style={{ color: "var(--text-muted)" }}>
                  Run <code className="font-mono font-bold">python main.py</code> in the backend. The frontend will automatically detect it and switch to live model predictions.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Code Snippet */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="eyebrow text-[10px]">backend/model_service.py HOOK</span>
            <button
              onClick={() => copyToClipboard(pythonSnippet, 1)}
              className="button button--sm button--outline text-[11px]"
            >
              {copiedIndex === 1 ? "✓ COPIED" : "COPY CODE"}
            </button>
          </div>

          <div 
            className="border p-4 font-mono text-[11px] overflow-x-auto leading-relaxed"
            style={{ borderColor: "var(--rule-strong)", backgroundColor: "var(--surface)", color: "var(--text)" }}
          >
            <pre>{pythonSnippet}</pre>
          </div>
        </div>

        {/* Terminal Run Box */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="eyebrow text-[10px]">TERMINAL LAUNCH COMMAND</span>
            <button
              onClick={() => copyToClipboard(terminalCmd, 2)}
              className="button button--sm button--outline text-[11px]"
            >
              {copiedIndex === 2 ? "✓ COPIED" : "COPY"}
            </button>
          </div>

          <div 
            className="border p-3 font-mono text-xs font-bold"
            style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)", color: "var(--text)" }}
          >
            {terminalCmd}
          </div>
        </div>

        {/* Footer */}
        <div className="flex justify-end pt-3 border-t" style={{ borderColor: "var(--rule)" }}>
          <button
            onClick={onClose}
            className="button button--sm"
          >
            CLOSE GUIDE
          </button>
        </div>
      </div>
    </div>
  );
}
