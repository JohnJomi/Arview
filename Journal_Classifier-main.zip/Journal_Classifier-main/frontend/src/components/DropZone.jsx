import React, { useState, useRef } from "react";
import { SAMPLE_PAPERS } from "../data/samplePapers";

export default function DropZone({ onClassify, isClassifying, progressStep }) {
  const [dragActive, setDragActive] = useState(false);
  const [inputMode, setInputMode] = useState("file");
  const [manualTitle, setManualTitle] = useState("");
  const [manualAbstract, setManualAbstract] = useState("");
  const fileInputRef = useRef(null);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type === "application/pdf" || file.name.endsWith(".pdf")) {
        onClassify({ file });
      } else {
        alert("Please drop a valid research paper PDF file.");
      }
    }
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      onClassify({ file });
    }
  };

  const handleSelectSample = (sample) => {
    onClassify({ sampleId: sample.id });
  };

  const handleManualSubmit = (e) => {
    e.preventDefault();
    if (!manualAbstract.trim()) return;
    onClassify({
      title: manualTitle.trim() || "Manual Research Input",
      text: manualAbstract.trim(),
    });
  };

  const pipelineStages = [
    { num: "01", title: "READING DOCUMENT", desc: "Extracting title, abstract, authors, and full text from PDF" },
    { num: "02", title: "GENERATING EMBEDDING", desc: "Mapping paper content into 768-dimensional SPECTER2 scientific space" },
    { num: "03", title: "CLASSIFYING TOPIC", desc: "Evaluating multi-label probabilities across scientific domains" },
    { num: "04", title: "CALIBRATING CONFIDENCE", desc: "Scaling confidence to guarantee honest probability scores" },
  ];

  return (
    <section className="space-y-6" aria-labelledby="input-heading">
      {/* Quick Start Guide Banner with Stark Border */}
      <div 
        className="border-2 p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
        style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}
      >
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="eyebrow text-[11px]">[ QUICK START GUIDE ]</span>
            <span className="font-mono text-xs uppercase font-bold" style={{ color: "var(--text)" }}>
              HOW TO CLASSIFY A PAPER
            </span>
          </div>
          <p className="text-xs sm:text-sm font-medium leading-relaxed" style={{ color: "var(--text)" }}>
            <strong>1.</strong> Upload any research paper in PDF format, OR <strong>2.</strong> Click one of the 5 sample benchmark papers below.
          </p>
        </div>

        {/* Input Mode Switcher with Red Active State */}
        <div className="flex border-2 text-xs font-bold uppercase shrink-0" style={{ borderColor: "var(--rule)" }}>
          <button
            onClick={() => setInputMode("file")}
            className="px-4 py-2 transition-colors cursor-pointer"
            style={{ 
              backgroundColor: inputMode === "file" ? "#FF0000" : "transparent",
              color: inputMode === "file" ? "#FFFFFF" : "var(--text)"
            }}
          >
            PDF File Upload
          </button>
          <button
            onClick={() => setInputMode("text")}
            className="px-4 py-2 border-l-2 transition-colors cursor-pointer"
            style={{ 
              borderColor: "var(--rule)",
              backgroundColor: inputMode === "text" ? "#FF0000" : "transparent",
              color: inputMode === "text" ? "#FFFFFF" : "var(--text)"
            }}
          >
            Paste Text
          </button>
        </div>
      </div>

      {/* Main Upload Box with Solid Hard Drop-Shadow */}
      {inputMode === "file" ? (
        <div
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          onClick={() => !isClassifying && fileInputRef.current?.click()}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => e.key === "Enter" && !isClassifying && fileInputRef.current?.click()}
          aria-label="Upload PDF Document"
          className="border-2 p-8 sm:p-12 text-center cursor-pointer select-none transition-all hard-drop-shadow"
          style={{
            borderColor: dragActive ? "#FF0000" : "var(--rule)",
            backgroundColor: dragActive 
              ? "var(--red-bg)" 
              : isClassifying 
              ? "var(--surface)" 
              : "var(--surface-card)"
          }}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf,application/pdf"
            className="hidden"
            onChange={handleFileChange}
            disabled={isClassifying}
          />

          {isClassifying ? (
            /* Progress State */
            <div className="max-w-xl mx-auto space-y-6 text-left">
              <div className="flex items-center justify-between border-b-2 pb-2" style={{ borderColor: "var(--rule)" }}>
                <span className="eyebrow">PROCESSING YOUR PAPER...</span>
                <span className="font-mono text-xs font-bold text-[#FF0000] animate-pulse">
                  STAGE [0{progressStep + 1}/04]
                </span>
              </div>

              <div className="space-y-2">
                {pipelineStages.map((stage, idx) => {
                  const isCurrent = progressStep === idx;
                  const isDone = progressStep > idx;

                  return (
                    <div 
                      key={stage.num} 
                      className="p-3 border-2 flex items-center justify-between"
                      style={{
                        borderColor: isCurrent ? "#FF0000" : "var(--rule)",
                        backgroundColor: isDone ? "var(--rule)" : "var(--surface-card)",
                        color: isDone ? "var(--bg)" : "var(--text)"
                      }}
                    >
                      <div className="flex items-center space-x-3">
                        <span className="font-mono text-xs font-bold" style={{ color: isCurrent ? "#FF0000" : "" }}>
                          {stage.num}
                        </span>
                        <div>
                          <span className="text-xs font-bold uppercase tracking-wider block">
                            {stage.title}
                          </span>
                          <span className="text-[11px] block mt-0.5 opacity-80">
                            {stage.desc}
                          </span>
                        </div>
                      </div>
                      <span className="font-mono text-[10px] uppercase font-black tracking-widest">
                        {isDone ? "[DONE]" : isCurrent ? "[RUNNING]" : "[WAITING]"}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            /* Idle Drag & Drop */
            <div className="space-y-4 max-w-xl mx-auto">
              <div className="eyebrow text-xs">
                [ DRAG &amp; DROP PDF FILE HERE // OR CLICK TO SELECT ]
              </div>

              <h3 className="text-2xl sm:text-3xl font-extrabold uppercase tracking-tight" style={{ color: "var(--text)" }}>
                UPLOAD YOUR RESEARCH PAPER PDF
              </h3>

              <p className="lead text-sm" style={{ color: "var(--text-muted)" }}>
                Supports papers from IEEE, arXiv, Springer, Nature, and ACM. We'll automatically extract the title, abstract, and content to predict its research domain.
              </p>

              <div className="pt-2">
                <span className="button text-xs">
                  CHOOSE PDF FROM COMPUTER →
                </span>
              </div>

              <p className="font-mono text-[11px] font-bold" style={{ color: "var(--text-subtle)" }}>
                Max file size: 50MB • All processing runs securely
              </p>
            </div>
          )}
        </div>
      ) : (
        /* Manual Text Form */
        <form 
          onSubmit={handleManualSubmit} 
          className="border-2 p-6 space-y-4 hard-drop-shadow"
          style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}
        >
          <div>
            <label className="eyebrow mb-1">
              PAPER TITLE [OPTIONAL]
            </label>
            <input
              type="text"
              placeholder="e.g. Attention Is All You Need"
              value={manualTitle}
              onChange={(e) => setManualTitle(e.target.value)}
              className="w-full border-2 p-3 text-sm focus:border-[#FF0000] font-sans"
              style={{ backgroundColor: "var(--surface-card)", borderColor: "var(--rule)", color: "var(--text)" }}
            />
          </div>

          <div>
            <label className="eyebrow mb-1">
              PAPER ABSTRACT OR EXCERPT [REQUIRED]
            </label>
            <textarea
              rows={5}
              placeholder="Paste the abstract or introduction of the research paper here..."
              value={manualAbstract}
              onChange={(e) => setManualAbstract(e.target.value)}
              required
              className="w-full border-2 p-3 text-sm focus:border-[#FF0000] font-sans leading-relaxed"
              style={{ backgroundColor: "var(--surface-card)", borderColor: "var(--rule)", color: "var(--text)" }}
            />
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              disabled={isClassifying || !manualAbstract.trim()}
              className="button"
            >
              CLASSIFY ABSTRACT →
            </button>
          </div>
        </form>
      )}

      {/* Benchmark Reference Sample Papers with Stark White/Red Borders */}
      <div className="space-y-3 pt-2">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between border-b-2 pb-2 gap-1" style={{ borderColor: "var(--rule)" }}>
          <div>
            <span className="eyebrow">
              TEST WITH 1-CLICK // NO PDF DOWNLOAD REQUIRED
            </span>
            <p className="text-xs font-medium" style={{ color: "var(--text-muted)" }}>
              Click any of these 5 landmark research papers to see how the system classifies different fields:
            </p>
          </div>
          <span className="font-mono text-[11px] font-bold uppercase text-[#FF0000]">
            SELECT ANY TO EVALUATE
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {SAMPLE_PAPERS.map((paper) => (
            <div
              key={paper.id}
              onClick={() => handleSelectSample(paper)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === "Enter" && handleSelectSample(paper)}
              className="border-2 p-4 transition-all cursor-pointer flex flex-col justify-between group hover:border-[#FF0000] hover:-translate-y-0.5 hover:shadow-[4px_4px_0px_#FF0000]"
              style={{ 
                borderColor: "var(--rule)", 
                backgroundColor: "var(--surface-card)"
              }}
            >
              <div>
                <div className="flex items-center justify-between border-b pb-1.5 mb-2" style={{ borderColor: "var(--rule)" }}>
                  <span className="font-mono text-xs font-black text-[#FF0000]">
                    [{paper.primaryCategory}]
                  </span>
                  <span className="font-mono text-[10px] font-bold uppercase" style={{ color: "var(--text-subtle)" }}>
                    {paper.venue}
                  </span>
                </div>

                <h4 
                  className="text-sm font-bold uppercase tracking-tight line-clamp-1 group-hover:text-[#FF0000] transition-colors"
                  style={{ color: "var(--text)" }}
                >
                  {paper.title}
                </h4>

                <p className="text-xs mt-1.5 line-clamp-2 leading-relaxed" style={{ color: "var(--text-muted)" }}>
                  {paper.abstract}
                </p>
              </div>

              <div className="mt-4 pt-2 border-t flex items-center justify-between font-mono text-[11px]" style={{ borderColor: "var(--rule)" }}>
                <span className="font-medium" style={{ color: "var(--text-subtle)" }}>{paper.authors[0]} et al.</span>
                <span className="font-black text-[#FF0000] uppercase flex items-center space-x-1 group-hover:underline">
                  <span>TEST THIS PAPER</span>
                  <span>→</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
