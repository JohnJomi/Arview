import React, { useState, useRef } from "react";
import { classifyPaper } from "../services/api";
import { SAMPLE_PAPERS } from "../data/samplePapers";
import { getCategoryById } from "../data/taxonomy";

export default function BatchClassifier({ onSelectPaperForDetail }) {
  const [queue, setQueue] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef(null);

  const handleFiles = (files) => {
    const newItems = Array.from(files).map((file, idx) => ({
      id: `batch-${Date.now()}-${idx}`,
      file,
      name: file.name,
      size: (file.size / (1024 * 1024)).toFixed(2) + " MB",
      status: "queued",
      result: null
    }));
    setQueue(prev => [...prev, ...newItems]);
  };

  const handleLoadSamples = () => {
    const sampleItems = SAMPLE_PAPERS.map(p => ({
      id: `sample-${p.id}`,
      name: `${p.title}.pdf`,
      size: "1.42 MB",
      status: "queued",
      sampleId: p.id,
      result: null
    }));
    setQueue(sampleItems);
  };

  const runBatchProcessing = async () => {
    if (queue.length === 0 || isProcessing) return;
    setIsProcessing(true);

    const updatedQueue = [...queue];

    for (let i = 0; i < updatedQueue.length; i++) {
      if (updatedQueue[i].status === "done") continue;

      updatedQueue[i].status = "processing";
      setQueue([...updatedQueue]);

      try {
        const res = await classifyPaper({
          file: updatedQueue[i].file,
          sampleId: updatedQueue[i].sampleId,
        });

        updatedQueue[i].status = "done";
        updatedQueue[i].result = res;
      } catch (err) {
        updatedQueue[i].status = "error";
      }

      setQueue([...updatedQueue]);
    }

    setIsProcessing(false);
  };

  const exportBatchCSV = () => {
    const headers = ["Title", "Primary Domain", "Code", "Calibrated Confidence", "Word Count", "Venue"];
    const rows = queue
      .filter(q => q.result)
      .map(q => {
        const cat = getCategoryById(q.result.primaryCategory);
        const score = Math.round((q.result.predictions?.[0]?.calibratedScore || 0.9) * 100);
        return [
          `"${q.result.title.replace(/"/g, '""')}"`,
          `"${cat.name}"`,
          `"${cat.id}"`,
          `"${score}%"`,
          `"${q.result.wordCount || 5000}"`,
          `"${q.result.venue || "arXiv"}"`
        ];
      });

    const csvContent = [headers.join(","), ...rows.map(r => r.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `batch_classification_results_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <section className="space-y-6" aria-labelledby="batch-heading">
      {/* Top Banner */}
      <div 
        className="border p-6 sm:p-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4"
        style={{ borderColor: "var(--rule-strong)", backgroundColor: "var(--surface-card)" }}
      >
        <div>
          <span className="eyebrow" id="batch-heading">BATCH PROCESSING // MULTIPLE PAPERS</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold uppercase tracking-tight mt-1" style={{ color: "var(--text)" }}>
            Classify Multiple Papers at Once
          </h2>
          <p className="lead text-sm max-w-xl mt-1" style={{ color: "var(--text-muted)" }}>
            Upload a batch of PDFs together. The system will process each one in sequence and allow you to export the entire categorized list to an Excel/CSV spreadsheet.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <input
            type="file"
            ref={fileInputRef}
            multiple
            accept=".pdf,application/pdf"
            className="hidden"
            onChange={(e) => handleFiles(e.target.files)}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="button button--sm button--outline"
          >
            + ADD PDF FILES
          </button>

          <button
            onClick={handleLoadSamples}
            className="button button--sm button--outline"
          >
            LOAD 5 TEST PAPERS
          </button>

          {queue.length > 0 && (
            <button
              onClick={runBatchProcessing}
              disabled={isProcessing}
              className="button button--sm"
            >
              {isProcessing ? "PROCESSING PAPERS..." : "START CLASSIFYING ALL →"}
            </button>
          )}

          {queue.some(q => q.status === "done") && (
            <button
              onClick={exportBatchCSV}
              className="button button--sm button--outline"
            >
              DOWNLOAD SPREADSHEET (CSV)
            </button>
          )}
        </div>
      </div>

      {/* Ledger Table */}
      {queue.length === 0 ? (
        <div 
          className="border p-12 text-center space-y-2"
          style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}
        >
          <span className="eyebrow text-xs">[ QUEUE READY ]</span>
          <h4 className="text-base font-bold uppercase" style={{ color: "var(--text)" }}>
            No Papers in the Batch Queue
          </h4>
          <p className="text-xs max-w-md mx-auto" style={{ color: "var(--text-muted)" }}>
            Click "+ ADD PDF FILES" to select multiple papers from your files, or click "LOAD 5 TEST PAPERS" to see how batch categorization works.
          </p>
        </div>
      ) : (
        <div 
          className="border overflow-x-auto"
          style={{ borderColor: "var(--rule-strong)", backgroundColor: "var(--surface-card)" }}
        >
          <table className="w-full text-left text-xs">
            <thead 
              className="border-b font-mono uppercase font-bold"
              style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)", color: "var(--text)" }}
            >
              <tr>
                <th className="px-5 py-3">FILE / DOCUMENT NAME</th>
                <th className="px-5 py-3">SIZE</th>
                <th className="px-5 py-3">STATUS</th>
                <th className="px-5 py-3">PREDICTED DOMAIN</th>
                <th className="px-5 py-3">CERTAINTY</th>
                <th className="px-5 py-3 text-right">ACTION</th>
              </tr>
            </thead>
            <tbody className="divide-y" style={{ borderColor: "var(--rule)" }}>
              {queue.map((item, idx) => {
                const result = item.result;
                const cat = result ? getCategoryById(result.primaryCategory) : null;
                const score = result?.predictions?.[0]?.calibratedScore || 0;

                return (
                  <tr key={item.id} className="transition-colors hover:opacity-90">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center space-x-2 font-mono">
                        <span style={{ color: "var(--text-subtle)" }}>
                          [{idx + 1 < 10 ? `0${idx + 1}` : idx + 1}]
                        </span>
                        <span className="font-bold uppercase line-clamp-1 max-w-sm" style={{ color: "var(--text)" }}>
                          {item.name}
                        </span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 font-mono" style={{ color: "var(--text-muted)" }}>
                      {item.size}
                    </td>
                    <td className="px-5 py-3.5 font-mono">
                      {item.status === "done" ? (
                        <span className="font-bold uppercase" style={{ color: "var(--text)" }}>
                          [COMPLETE ✓]
                        </span>
                      ) : item.status === "processing" ? (
                        <span className="text-red-600 font-bold uppercase animate-pulse">
                          [CLASSIFYING...]
                        </span>
                      ) : (
                        <span className="uppercase" style={{ color: "var(--text-subtle)" }}>
                          [WAITING IN LINE]
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-3.5 font-mono">
                      {cat ? (
                        <div className="flex items-center space-x-1.5">
                          <span className="font-bold uppercase" style={{ color: "var(--text)" }}>{cat.name}</span>
                          <span className="text-red-600 font-bold">[{cat.id}]</span>
                        </div>
                      ) : (
                        <span style={{ color: "var(--text-subtle)" }}>—</span>
                      )}
                    </td>
                    <td className="px-5 py-3.5 font-mono font-bold" style={{ color: "var(--text)" }}>
                      {result ? `${Math.round(score * 100)}%` : "—"}
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      {result && (
                        <button
                          onClick={() => onSelectPaperForDetail(result)}
                          className="button button--sm button--outline text-[11px]"
                        >
                          VIEW FULL DETAILS →
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
