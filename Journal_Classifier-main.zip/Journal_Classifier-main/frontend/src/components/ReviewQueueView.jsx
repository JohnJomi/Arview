import React, { useState, useEffect } from "react";
import { getCategoryById } from "../data/taxonomy";

export default function ReviewQueueView() {
  const [reviews, setReviews] = useState([]);

  useEffect(() => {
    loadReviews();
  }, []);

  const loadReviews = () => {
    const saved = JSON.parse(localStorage.getItem("journal_classifier_reviews") || "[]");
    setReviews(saved);
  };

  const handleClear = () => {
    if (confirm("Delete all human audit records from local registry?")) {
      localStorage.removeItem("journal_classifier_reviews");
      setReviews([]);
    }
  };

  const handleExportJSONL = () => {
    const jsonlContent = reviews.map(r => JSON.stringify(r)).join("\n");
    const blob = new Blob([jsonlContent], { type: "application/x-jsonlines" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `retraining_dataset_${new Date().toISOString().slice(0, 10)}.jsonl`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <section className="space-y-6" aria-labelledby="review-queue-heading">
      {/* Top Banner */}
      <div 
        className="border p-6 sm:p-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4"
        style={{ borderColor: "var(--rule-strong)", backgroundColor: "var(--surface-card)" }}
      >
        <div>
          <span className="eyebrow" id="review-queue-heading">QUALITY CONTROL // 03</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold uppercase tracking-tight mt-1" style={{ color: "var(--text)" }}>
            Reviewed Papers &amp; Validations
          </h2>
          <p className="lead text-sm max-w-xl mt-1" style={{ color: "var(--text-muted)" }}>
            Whenever you verify or correct a paper category, the decision is logged here. This verified data can be exported to teach the model how to improve.
          </p>
        </div>

        <div className="flex items-center space-x-2 shrink-0">
          {reviews.length > 0 && (
            <>
              <button
                onClick={handleClear}
                className="button button--sm button--outline"
              >
                CLEAR LEDGER
              </button>
              <button
                onClick={handleExportJSONL}
                className="button button--sm"
              >
                DOWNLOAD VERIFIED DATA (.JSONL) →
              </button>
            </>
          )}
        </div>
      </div>

      {/* Table */}
      {reviews.length === 0 ? (
        <div 
          className="border p-12 text-center space-y-2"
          style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}
        >
          <span className="eyebrow text-xs">[ NO SAVED VERIFICATIONS YET ]</span>
          <h4 className="text-base font-bold uppercase" style={{ color: "var(--text)" }}>
            All Processed Papers Are Ready For Review
          </h4>
          <p className="text-xs max-w-md mx-auto" style={{ color: "var(--text-muted)" }}>
            When you classify a paper and click "Change or Confirm Category", your verified decisions will be saved in this table.
          </p>
        </div>
      ) : (
        <div 
          className="border overflow-x-auto"
          style={{ borderColor: "var(--rule-strong)", backgroundColor: "var(--surface-card)" }}
        >
          <table className="w-full text-left text-xs">
            <thead 
              className="border-b font-mono uppercase font-bold"
              style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)", color: "var(--text)" }}
            >
              <tr>
                <th className="px-5 py-3">PAPER TITLE &amp; NOTES</th>
                <th className="px-5 py-3">AI PREDICTION</th>
                <th className="px-5 py-3">VERIFIED FIELD</th>
                <th className="px-5 py-3">STATUS</th>
                <th className="px-5 py-3">DATE</th>
              </tr>
            </thead>
            <tbody className="divide-y" style={{ borderColor: "var(--rule)" }}>
              {reviews.map((rev, idx) => {
                const humanCat = getCategoryById(rev.humanValidatedCategory);

                return (
                  <tr key={idx} className="transition-colors hover:opacity-90">
                    <td className="px-5 py-3.5">
                      <span className="font-bold uppercase block line-clamp-1 max-w-md" style={{ color: "var(--text)" }}>
                        {rev.title}
                      </span>
                      {rev.reviewerNotes && (
                        <span className="text-[11px] font-mono block mt-0.5" style={{ color: "var(--text-muted)" }}>
                          NOTE: "{rev.reviewerNotes}"
                        </span>
                      )}
                    </td>
                    <td className="px-5 py-3.5 font-mono">
                      <span className="border px-2 py-0.5" style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)", color: "var(--text)" }}>
                        [{rev.modelPredictedCategory}] {Math.round((rev.modelConfidence || 0) * 100)}%
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center space-x-1.5 font-mono">
                        <span className="font-bold uppercase" style={{ color: "var(--text)" }}>
                          {humanCat.name}
                        </span>
                        <span className="text-red-600 font-bold">
                          [{humanCat.id}]
                        </span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 font-mono">
                      <span 
                        className="px-2 py-0.5 text-[10px] font-bold uppercase border"
                        style={{
                          borderColor: rev.verdict === "confirm_predicted" ? "var(--rule-strong)" : "var(--red)",
                          backgroundColor: rev.verdict === "confirm_predicted" ? "var(--rule-strong)" : "transparent",
                          color: rev.verdict === "confirm_predicted" ? "var(--bg)" : "var(--red)"
                        }}
                      >
                        {rev.verdict.replace(/_/g, " ")}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 font-mono text-[11px] whitespace-nowrap" style={{ color: "var(--text-muted)" }}>
                      {new Date(rev.reviewedAt).toISOString().slice(0, 10)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
