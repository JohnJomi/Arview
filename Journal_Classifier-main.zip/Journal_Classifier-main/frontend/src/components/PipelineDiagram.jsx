import React, { useState } from "react";

export default function PipelineDiagram({ onOpenModelGuide }) {
  const [activeNode, setActiveNode] = useState("classifier");

  const nodes = [
    {
      id: "input",
      num: "01",
      title: "INPUT PAPER PDF",
      category: "STEP 1: UPLOAD",
      desc: "Raw PDF research document upload or stream from arXiv / IEEE Xplore API.",
      details: "Accepts digital academic papers up to 50MB. Reads multi-column text, titles, abstracts, and authors cleanly.",
      fileHook: "backend/pdf_extractor.py: extract_text_from_pdf()",
      status: "OPERATIONAL"
    },
    {
      id: "extraction",
      num: "02",
      title: "TEXT EXTRACTION",
      category: "STEP 2: PARSE",
      desc: "Fast text extraction, title identification, and abstract segmentation without OCR distortion.",
      details: "Extracts sections and text without distortion to prepare it for vectorization.",
      fileHook: "backend/pdf_extractor.py: parse_paper_metadata()",
      status: "ACTIVE"
    },
    {
      id: "specter2",
      num: "03",
      title: "SPECTER2 EMBEDDING",
      category: "STEP 3: ENCODE",
      desc: "Scientific transformer converts paper content into a 768-dimensional numerical coordinate.",
      details: "allenai/specter2 model generates document representations so papers with similar meanings land near each other.",
      fileHook: "backend/model_service.py: SPECTER2EmbeddingService.encode()",
      status: "READY FOR WEIGHTS"
    },
    {
      id: "classifier",
      num: "04",
      title: "AI CLASSIFIER",
      category: "STEP 4: PREDICT",
      desc: "Evaluates multi-label probabilities across scientific fields (CS, Math, Physics, Biology, Finance).",
      details: "This is where your trained model connects! Accepts the 768-d vector and outputs class likelihoods.",
      fileHook: "backend/model_service.py: DomainClassifierService.predict()",
      status: "CONNECT MODEL HERE"
    },
    {
      id: "calibration",
      num: "05",
      title: "CONFIDENCE CALIBRATOR",
      category: "STEP 5: CALIBRATE",
      desc: "Temperature scaling ensures that a 90% score truly means 90% real-world accuracy.",
      details: "Guarantees honest percentage scores so users know when to trust the prediction or review it.",
      fileHook: "backend/model_service.py: ConfidenceCalibrator.calibrate()",
      status: "ACTIVE (T=1.15)"
    },
    {
      id: "output",
      num: "06",
      title: "RESULTS DISPLAY",
      category: "STEP 6: DELIVER",
      desc: "Delivers the classified category, confidence score, and exportable citations directly to the screen.",
      details: "Structured JSON response formatted cleanly for the user interface.",
      fileHook: "backend/main.py: /api/classify response schema",
      status: "ACTIVE"
    },
    {
      id: "human_review",
      num: "07",
      title: "HUMAN AUDIT QUEUE",
      category: "QUALITY CONTROL",
      desc: "Allows human reviewers to double-check any paper where the AI is uncertain (< 70%).",
      details: "Any human corrections are stored so the model can be retrained and improved over time.",
      fileHook: "backend/main.py: /api/feedback & local ledger",
      status: "ACTIVE IN UI"
    },
    {
      id: "serving",
      num: "08",
      title: "FASTAPI SERVER",
      category: "BACKEND API",
      desc: "Fast Python backend running on port 8000 handling PDF ingestion and model inference.",
      details: "High-throughput asynchronous server ready for production deployment with Docker or GPU hosting.",
      fileHook: "backend/main.py (FastAPI / Uvicorn)",
      status: "ONLINE :8000"
    },
    {
      id: "monitoring",
      num: "09",
      title: "SYSTEM MONITORING",
      category: "RELIABILITY",
      desc: "Tracks processing latency, incoming topics, and model drift over time.",
      details: "Ensures the system stays accurate as new scientific topics emerge over time.",
      fileHook: "backend/model_service.py: DriftTracker",
      status: "OPERATIONAL"
    }
  ];

  const selected = nodes.find(n => n.id === activeNode) || nodes[3];

  return (
    <section className="space-y-6" aria-labelledby="architecture-heading">
      {/* Top Banner */}
      <div 
        className="border p-6 sm:p-8 flex flex-col sm:flex-row sm:items-end justify-between gap-4"
        style={{ borderColor: "var(--rule-strong)", backgroundColor: "var(--surface-card)" }}
      >
        <div>
          <span className="eyebrow" id="architecture-heading">HOW IT WORKS // SYSTEM ARCHITECTURE</span>
          <h2 className="text-2xl sm:text-3xl font-extrabold uppercase tracking-tight mt-1" style={{ color: "var(--text)" }}>
            Visual Explanation of the Pipeline
          </h2>
          <p className="lead text-sm max-w-xl mt-1" style={{ color: "var(--text-muted)" }}>
            Here is what happens behind the scenes from the moment you drop in a PDF until the predicted category appears. Click any step to inspect how it works:
          </p>
        </div>

        <button
          onClick={onOpenModelGuide}
          className="button button--sm shrink-0"
        >
          CONNECT MODEL INSTRUCTIONS →
        </button>
      </div>

      {/* 6-Stage Primary Sequential Grid */}
      <div 
        className="border p-6 sm:p-8 space-y-6"
        style={{ borderColor: "var(--rule-strong)", backgroundColor: "var(--surface-card)" }}
      >
        <div className="border-b pb-2 flex items-center justify-between" style={{ borderColor: "var(--rule)" }}>
          <span className="eyebrow text-[10px]">
            6-STEP CLASSIFICATION PIPELINE [01 — 06]
          </span>
          <span className="font-mono text-[10px] uppercase" style={{ color: "var(--text-subtle)" }}>
            CLICK ANY STEP BELOW TO READ DETAILS
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2">
          {nodes.slice(0, 6).map((node) => {
            const isSelected = activeNode === node.id;

            return (
              <button
                key={node.id}
                onClick={() => setActiveNode(node.id)}
                className="p-4 border text-left transition-colors flex flex-col justify-between cursor-pointer"
                style={{
                  borderColor: isSelected ? "var(--red)" : "var(--rule)",
                  backgroundColor: isSelected ? "var(--rule-strong)" : "var(--surface)",
                  color: isSelected ? "var(--bg)" : "var(--text)"
                }}
              >
                <div>
                  <div className="flex items-center justify-between font-mono text-[10px] pb-2 border-b mb-2" style={{ borderColor: "var(--rule)" }}>
                    <span className={isSelected ? "text-red-500 font-bold" : "text-neutral-500"}>
                      [{node.num}]
                    </span>
                    <span className="uppercase text-[9px] font-bold opacity-80">
                      {node.category}
                    </span>
                  </div>

                  <h4 className="text-xs font-black uppercase tracking-tight line-clamp-2">
                    {node.title}
                  </h4>
                </div>

                <div className="mt-4 pt-2 border-t font-mono text-[10px]" style={{ borderColor: "var(--rule)" }}>
                  {node.id === "classifier" ? (
                    <span className="text-red-500 font-bold">
                      YOUR MODEL GOES HERE →
                    </span>
                  ) : (
                    <span style={{ color: isSelected ? "var(--text-muted)" : "var(--text-subtle)" }}>
                      {node.status}
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Supporting Governance Nodes */}
        <div className="pt-2">
          <div className="border-b pb-2 mb-3" style={{ borderColor: "var(--rule)" }}>
            <span className="eyebrow text-[10px]">
              QUALITY CONTROL &amp; BACKEND SERVING [07 — 09]
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            {nodes.slice(6).map((node) => {
              const isSelected = activeNode === node.id;

              return (
                <button
                  key={node.id}
                  onClick={() => setActiveNode(node.id)}
                  className="p-4 border text-left transition-colors flex items-start space-x-3 cursor-pointer"
                  style={{
                    borderColor: isSelected ? "var(--red)" : "var(--rule)",
                    backgroundColor: isSelected ? "var(--rule-strong)" : "var(--surface)",
                    color: isSelected ? "var(--bg)" : "var(--text)"
                  }}
                >
                  <span className={`font-mono text-xs font-bold ${isSelected ? "text-red-500" : "text-neutral-500"}`}>
                    [{node.num}]
                  </span>
                  <div>
                    <span className="text-[9px] font-mono uppercase font-bold opacity-75 block">
                      {node.category}
                    </span>
                    <h5 className="text-xs font-black uppercase tracking-tight mt-0.5">
                      {node.title}
                    </h5>
                    <p className="text-[11px] mt-1 line-clamp-1 opacity-80">
                      {node.desc}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Detailed Inspector Box */}
        <div 
          className="border-2 p-6 space-y-4"
          style={{ borderColor: "var(--rule-strong)", backgroundColor: "var(--surface)" }}
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b pb-3 gap-2" style={{ borderColor: "var(--rule)" }}>
            <div className="flex items-center space-x-3">
              <span className="font-mono text-sm font-bold text-red-600">
                [{selected.num}]
              </span>
              <h4 className="text-base font-black uppercase tracking-tight" style={{ color: "var(--text)" }}>
                {selected.title}
              </h4>
              <span className="font-mono text-xs" style={{ color: "var(--text-subtle)" }}>
                // {selected.category}
              </span>
            </div>

            <div className="font-mono text-xs">
              <span className="uppercase" style={{ color: "var(--text-subtle)" }}>STATUS: </span>
              <span 
                className="font-bold border px-2 py-0.5"
                style={{ 
                  backgroundColor: "var(--surface-card)", 
                  borderColor: "var(--rule-strong)",
                  color: "var(--text)"
                }}
              >
                {selected.status}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            <div>
              <span className="eyebrow text-[10px] mb-1">WHAT HAPPENS IN THIS STEP:</span>
              <p className="leading-relaxed text-sm" style={{ color: "var(--text-muted)" }}>
                {selected.details}
              </p>
            </div>

            <div className="space-y-1">
              <span className="eyebrow text-[10px] mb-1">PYTHON CODE LOCATION (WHERE TO PLUG IN):</span>
              <div 
                className="border p-3 font-mono text-xs"
                style={{ 
                  borderColor: "var(--rule)", 
                  backgroundColor: "var(--surface-card)",
                  color: "var(--text)"
                }}
              >
                {selected.fileHook}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
