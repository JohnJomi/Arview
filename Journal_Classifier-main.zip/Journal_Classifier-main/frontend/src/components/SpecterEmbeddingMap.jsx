import React from "react";
import { getCategoryById } from "../data/taxonomy";

export default function SpecterEmbeddingMap({ paper }) {
  if (!paper) return null;

  const embedding = paper.embeddingPreview || {
    dim: 768,
    norm: 1.0,
    pcaCoords: [-0.3, 0.2],
    topDimensions: [0.12, -0.05, 0.22, -0.18, 0.09, 0.14, -0.07, 0.03],
    nearestNeighbors: []
  };

  const CLUSTERS = [
    { label: "CS: NLP & AI", x: -0.6, y: 0.45 },
    { label: "CS: VISION", x: -0.5, y: -0.65 },
    { label: "STAT: ML", x: -0.2, y: 0.1 },
    { label: "PHYS: QUANTUM", x: 0.7, y: 0.4 },
    { label: "BIO: GENOMICS", x: 0.65, y: -0.55 },
    { label: "FIN: QUANT", x: 0.25, y: 0.18 },
    { label: "MATH: PROB", x: 0.15, y: 0.7 }
  ];

  const mapX = (val) => 200 + val * 160;
  const mapY = (val) => 200 - val * 160;

  const currentPaperX = mapX(embedding.pcaCoords[0]);
  const currentPaperY = mapY(embedding.pcaCoords[1]);
  const primaryCat = getCategoryById(paper.primaryCategory);

  return (
    <section 
      className="border-2 p-6 space-y-6"
      style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface-card)" }}
      aria-labelledby="manifold-heading"
    >
      {/* Title & Pop Monospaced Metrics Header */}
      <div className="border-b-2 pb-4 space-y-3" style={{ borderColor: "var(--rule)" }}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <span className="eyebrow" id="manifold-heading">TOPIC LANDSCAPE PROJECTION // 03</span>
            <h3 className="text-xl font-bold uppercase tracking-tight mt-0.5" style={{ color: "var(--text)" }}>
              Topic Landscape Projection
            </h3>
          </div>

          {/* Popping Monospaced Vector Metric Badges */}
          <div className="flex items-center space-x-2">
            <span 
              className="font-mono text-xs font-black px-2.5 py-1 border-2 border-[#FF0000] text-[#FF0000] tracking-wider"
              style={{ backgroundColor: "var(--red-bg)" }}
            >
              DIM: 768
            </span>
            <span 
              className="font-mono text-xs font-black px-2.5 py-1 border-2 tracking-wider"
              style={{ borderColor: "var(--rule)", color: "var(--text)" }}
            >
              NORM: {embedding.norm?.toFixed(2) || "1.00"}
            </span>
          </div>
        </div>

        <p className="text-xs leading-relaxed" style={{ color: "var(--text-muted)" }}>
          Visual representation of how your paper maps onto the global scientific landscape based on its text semantics.
        </p>
      </div>

      {/* SVG Cartesian Coordinate Map with Stark Borders */}
      <div 
        className="border-2 p-4 flex flex-col items-center"
        style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}
      >
        <div 
          className="w-full flex items-center justify-between font-mono text-[11px] pb-2 mb-2 border-b uppercase"
          style={{ borderColor: "var(--rule)" }}
        >
          <span className="font-black text-[#FF0000]">[CARTESIAN LATENT SPACE]</span>
          {/* Popping Coordinate Readout */}
          <span className="font-mono font-black text-xs px-2 py-0.5 border-2 border-[#FF0000] bg-[#FF0000] text-white">
            X:{embedding.pcaCoords[0].toFixed(2)} | Y:{embedding.pcaCoords[1].toFixed(2)}
          </span>
        </div>

        <svg viewBox="0 0 400 400" className="w-full h-64">
          {/* Canvas Background with Stark Border */}
          <rect x="0" y="0" width="400" height="400" fill="var(--surface-card)" stroke="var(--rule)" strokeWidth="2" />
          
          {/* Grid Lines with Stark Contrast */}
          <line x1="40" y1="20" x2="40" y2="380" stroke="var(--rule)" strokeOpacity="0.25" strokeDasharray="3 3" />
          <line x1="120" y1="20" x2="120" y2="380" stroke="var(--rule)" strokeOpacity="0.25" strokeDasharray="3 3" />
          <line x1="280" y1="20" x2="280" y2="380" stroke="var(--rule)" strokeOpacity="0.25" strokeDasharray="3 3" />
          <line x1="360" y1="20" x2="360" y2="380" stroke="var(--rule)" strokeOpacity="0.25" strokeDasharray="3 3" />
          <line x1="20" y1="40" x2="380" y2="40" stroke="var(--rule)" strokeOpacity="0.25" strokeDasharray="3 3" />
          <line x1="20" y1="120" x2="380" y2="120" stroke="var(--rule)" strokeOpacity="0.25" strokeDasharray="3 3" />
          <line x1="20" y1="280" x2="380" y2="280" stroke="var(--rule)" strokeOpacity="0.25" strokeDasharray="3 3" />
          <line x1="20" y1="360" x2="380" y2="360" stroke="var(--rule)" strokeOpacity="0.25" strokeDasharray="3 3" />

          {/* Central Axes */}
          <line x1="200" y1="20" x2="200" y2="380" stroke="var(--text)" strokeWidth="1.5" />
          <line x1="20" y1="200" x2="380" y2="200" stroke="var(--text)" strokeWidth="1.5" />

          {/* Popping Monospaced Axis Numbers */}
          <text x="35" y="195" fill="var(--text-muted)" fontFamily="JetBrains Mono, monospace" fontSize="9" fontWeight="900">-1.0</text>
          <text x="115" y="195" fill="var(--text-muted)" fontFamily="JetBrains Mono, monospace" fontSize="9" fontWeight="900">-0.5</text>
          <text x="275" y="195" fill="var(--text-muted)" fontFamily="JetBrains Mono, monospace" fontSize="9" fontWeight="900">+0.5</text>
          <text x="355" y="195" fill="var(--text-muted)" fontFamily="JetBrains Mono, monospace" fontSize="9" fontWeight="900">+1.0</text>
          <text x="205" y="45" fill="var(--text-muted)" fontFamily="JetBrains Mono, monospace" fontSize="9" fontWeight="900">+1.0</text>
          <text x="205" y="365" fill="var(--text-muted)" fontFamily="JetBrains Mono, monospace" fontSize="9" fontWeight="900">-1.0</text>

          {/* Known Field Clusters */}
          {CLUSTERS.map((c, i) => {
            const cx = mapX(c.x);
            const cy = mapY(c.y);
            return (
              <g key={i}>
                <rect x={cx - 3.5} y={cy - 3.5} width="7" height="7" fill="var(--text)" stroke="var(--bg)" strokeWidth="1" />
                <text
                  x={cx}
                  y={cy + 13}
                  textAnchor="middle"
                  fill="var(--text)"
                  fontFamily="JetBrains Mono, monospace"
                  fontSize="9"
                  fontWeight="900"
                  letterSpacing="0.05em"
                >
                  {c.label}
                </text>
              </g>
            );
          })}

          {/* Trajectory Guide Line */}
          <line
            x1={200}
            y1={200}
            x2={currentPaperX}
            y2={currentPaperY}
            stroke="#FF0000"
            strokeWidth="2"
            strokeDasharray="4 4"
          />

          {/* Current Paper Stark Red Target */}
          <rect
            x={currentPaperX - 7}
            y={currentPaperY - 7}
            width="14"
            height="14"
            fill="#FF0000"
            stroke="var(--rule)"
            strokeWidth="1.5"
          />
          <rect
            x={currentPaperX - 2}
            y={currentPaperY - 2}
            width="4"
            height="4"
            fill="#FFFFFF"
          />
          <text
            x={currentPaperX}
            y={currentPaperY - 12}
            textAnchor="middle"
            fill="#FF0000"
            fontFamily="JetBrains Mono, monospace"
            fontSize="11"
            fontWeight="900"
          >
            TARGET
          </text>
        </svg>

        <div 
          className="w-full flex items-center justify-between font-mono text-[11px] pt-2 border-t mt-1"
          style={{ borderColor: "var(--rule)", color: "var(--text)" }}
        >
          <span className="font-bold">NEAREST CLUSTER:</span>
          <span className="font-black text-[#FF0000] uppercase underline">{primaryCat.name}</span>
        </div>
      </div>

      {/* Nearest Benchmark Matches with Popping Monospaced Numbers */}
      <div 
        className="border-2 p-4 space-y-3"
        style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}
      >
        <span className="eyebrow text-[10px]">MOST SIMILAR PUBLISHED PAPERS</span>
        
        <div className="divide-y-2" style={{ borderColor: "var(--rule)" }}>
          {embedding.nearestNeighbors && embedding.nearestNeighbors.length > 0 ? (
            embedding.nearestNeighbors.map((nb, idx) => (
              <div key={idx} className="py-2.5 flex items-center justify-between text-xs">
                <div className="pr-2">
                  <p className="font-bold uppercase line-clamp-1" style={{ color: "var(--text)" }}>{nb.title}</p>
                  <span className="font-mono text-[11px] text-[#FF0000] font-black">[{nb.domain}]</span>
                </div>
                {/* Popping Monospaced Percentage Number */}
                <span 
                  className="font-mono font-black text-xs px-2 py-0.5 border-2 border-[#FF0000] text-[#FF0000] bg-white dark:bg-black shrink-0 tracking-wider"
                >
                  {Math.round(nb.similarity * 100)}% MATCH
                </span>
              </div>
            ))
          ) : (
            <p className="text-xs italic py-2" style={{ color: "var(--text-subtle)" }}>
              Matched against scientific corpus database.
            </p>
          )}
        </div>
      </div>

      {/* 768-D Vector Slice Manifest with Popping Monospaced Digits */}
      <div 
        className="border-2 p-4 space-y-2"
        style={{ borderColor: "var(--rule)", backgroundColor: "var(--surface)" }}
      >
        <div className="flex items-center justify-between">
          <span className="eyebrow text-[10px]">768-D VECTOR NUMERICAL SLICE</span>
          <span className="font-mono text-[10px] font-bold" style={{ color: "var(--text)" }}>INDICES [0:7]</span>
        </div>

        <div className="grid grid-cols-4 gap-1.5 font-mono">
          {embedding.topDimensions?.map((val, idx) => (
            <div 
              key={idx} 
              className="border-2 p-1.5 text-center font-mono font-black text-xs"
              style={{
                borderColor: val > 0 ? "#FF0000" : "var(--rule)",
                backgroundColor: "var(--surface-card)",
                color: val > 0 ? "#FF0000" : "var(--text)"
              }}
            >
              {val > 0 ? `+${val.toFixed(3)}` : val.toFixed(3)}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
