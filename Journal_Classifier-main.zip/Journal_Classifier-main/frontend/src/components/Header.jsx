import React from "react";

export default function Header({ 
  activeTab, 
  setActiveTab, 
  backendStatus, 
  reviewCount,
  onOpenModelGuide,
  theme,
  onToggleTheme
}) {
  const tabs = [
    { id: "single", num: "01", label: "Classify Paper", hint: "Analyze 1 Document" },
    { id: "batch", num: "02", label: "Batch Process", hint: "Multiple Documents" },
    { 
      id: "review", 
      num: "03", 
      label: "Review Queue", 
      hint: "Check Results",
      badge: reviewCount > 0 ? reviewCount : null 
    },
    { id: "pipeline", num: "04", label: "How It Works", hint: "System Diagram" },
  ];

  return (
    <header className="border-b-2 sticky top-0 z-40" style={{ borderColor: "var(--rule)", backgroundColor: "var(--bg)" }}>
      {/* Top Meta Bar with Stark Border */}
      <div 
        className="max-w-[78rem] mx-auto px-6 py-2 border-b flex flex-wrap items-center justify-between text-xs font-mono tracking-wider gap-2"
        style={{ borderColor: "var(--rule)", color: "var(--text-muted)" }}
      >
        <div className="flex items-center space-x-3">
          <span className="font-bold uppercase tracking-widest text-[#FF0000]">[ SYSTEM // 01 ]</span>
          <span className="hidden sm:inline font-bold">RESEARCH PAPER DOMAIN CLASSIFIER</span>
        </div>

        {/* Top-Right Tools Bar with Theme Toggle */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1.5 font-bold">
            <span 
              className="w-2.5 h-2.5 shrink-0"
              style={{ backgroundColor: backendStatus?.online ? "var(--text)" : "#FF0000" }}
              aria-hidden="true"
            />
            <span className="uppercase" style={{ color: "var(--text)" }}>
              {backendStatus?.online ? "BACKEND: ONLINE (:8000)" : "MODE: DEMO RUNTIME"}
            </span>
          </div>

          <span style={{ color: "var(--rule)" }}>|</span>

          {/* Theme Toggle Button in the Top Right Corner */}
          <button
            onClick={onToggleTheme}
            aria-label={`Switch to ${theme === "dark" ? "Light" : "Dark"} theme`}
            title={`Click to switch to ${theme === "dark" ? "Light" : "Dark"} mode`}
            className="flex items-center space-x-2 px-3 py-1 border-2 transition-all cursor-pointer font-mono text-[11px] font-black uppercase hover:border-[#FF0000]"
            style={{ 
              borderColor: "var(--rule)", 
              backgroundColor: "var(--surface)", 
              color: "var(--text)" 
            }}
          >
            <span>{theme === "dark" ? "🌙 DARK" : "☀️ LIGHT"}</span>
            <span className="text-[10px] text-[#FF0000] font-black underline">TOGGLE</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Row */}
      <div className="max-w-[78rem] mx-auto px-6">
        <div className="flex items-stretch justify-between min-h-[4.5rem]">
          {/* Brand */}
          <div 
            onClick={() => setActiveTab("single")}
            className="flex items-center space-x-3 pr-8 border-r cursor-pointer select-none"
            style={{ borderColor: "var(--rule)" }}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => e.key === "Enter" && setActiveTab("single")}
          >
            <div 
              className="w-9 h-9 flex items-center justify-center font-black text-sm tracking-tighter"
              style={{ backgroundColor: "#FF0000", color: "#FFFFFF" }}
            >
              SN
            </div>
            <div>
              <div className="font-extrabold text-lg tracking-tighter uppercase leading-none" style={{ color: "var(--text)" }}>
                SPECTER<span className="text-[#FF0000]">.</span>NET
              </div>
              <div className="text-[10px] tracking-widest uppercase font-mono mt-0.5 font-bold" style={{ color: "var(--text-muted)" }}>
                JOURNAL CLASSIFIER
              </div>
            </div>
          </div>

          {/* Navigation Tabs - Consistent Red for Active State */}
          <nav className="flex items-stretch flex-1 overflow-x-auto" aria-label="Main Navigation">
            {tabs.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  aria-current={isActive ? "page" : undefined}
                  className="flex flex-col justify-center px-5 border-r text-left transition-all relative cursor-pointer group"
                  style={{ 
                    borderColor: "var(--rule)",
                    backgroundColor: isActive ? "#FF0000" : "transparent",
                    color: isActive ? "#FFFFFF" : "var(--text)"
                  }}
                >
                  <div className="flex items-center space-x-2">
                    <span 
                      className="font-mono text-[10px] font-black"
                      style={{ color: isActive ? "#FFFFFF" : "#FF0000" }}
                    >
                      {tab.num}
                    </span>
                    <span className="text-xs font-black uppercase tracking-wider">
                      {tab.label}
                    </span>
                    {tab.badge && (
                      <span className="px-1.5 py-0.5 text-[10px] font-mono bg-black text-white font-bold">
                        {tab.badge}
                      </span>
                    )}
                  </div>
                  <span 
                    className="text-[10px] font-mono mt-0.5 block opacity-90"
                    style={{ color: isActive ? "#FFFFFF" : "var(--text-muted)" }}
                  >
                    {tab.hint}
                  </span>
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-1 bg-white" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Connect Model Action */}
          <div className="flex items-center pl-6">
            <button
              onClick={onOpenModelGuide}
              className="button button--sm button--outline text-xs whitespace-nowrap"
              aria-label="Connect Trained Model Documentation"
              title="View instructions to plug your trained model into the backend"
            >
              <span>CONNECT MODEL</span>
              <span className="text-[#FF0000] font-mono font-bold">→</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
