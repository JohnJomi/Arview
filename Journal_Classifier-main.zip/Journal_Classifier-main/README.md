# SPECTER-Net: Research Paper Domain & Taxonomy Classifier

A modern, production-ready frontend and serving infrastructure for classifying research papers (PDFs) into scientific taxonomies using **SPECTER2 embeddings**, **multi-label domain classifiers** (Logistic Regression, MLP, XGBoost), and **temperature-scaled confidence calibration**.

---

## 🏗️ Architecture Overview

The pipeline implements the full end-to-end system design:
```
[ Research Paper PDF ]
          │
          ▼
[ Paper Ingestion & Extraction ]  -->  PyMuPDF (fitz) text & metadata extraction
          │
          ▼
[ SPECTER2 Embedding Service ]    -->  Hosted frozen transformer (768-d semantic vector)
          │
          ▼
[ Multi-Label Classifier ]        -->  LogReg / MLP / XGBoost (cross-domain probabilities)
          │
          ▼
[ Confidence Calibration ]        -->  Temperature scaling (softmax(logits / T))
          │
          ▼
[ Classification Output ]         -->  Primary domain + secondary rankings + structured results
          │
          ├── [ Human Review Dashboard ]  -->  Low-confidence inspection (< 70%) & retraining dataset
          └── [ Monitoring & Drift ]      -->  Embedding drift telemetry & latency tracking
```

---

## 🚀 Quickstart

### 1. Launch the Frontend
The frontend is built with React, Vite, and Tailwind CSS.
```bash
cd frontend
npm install
npm run dev
```
Open **[http://localhost:5173](http://localhost:5173)** in your browser.

> **Note**: The frontend works **100% standalone out of the box** in interactive demonstration mode, with 5 benchmark research papers (*Attention Is All You Need*, *ResNet*, *Quantum Supremacy*, *CRISPR-Cas9*, and ambiguous multi-domain papers), 2D embedding space projections, and the human review dashboard.

---

### 2. Launch the FastAPI Serving Backend (Optional / Ready for Model)
The Python backend uses FastAPI, PyMuPDF, and Scikit-Learn:
```bash
cd backend
pip install -r requirements.txt
python main.py
```
Backend will be live on **`http://localhost:8000`** with interactive Swagger documentation at **`http://localhost:8000/docs`**. The frontend automatically detects the backend when online.

---

## 🔌 Connecting Your Model

Once your model is trained, connecting it takes **just 2 minutes**:

### Step 1: Place your model weights in `backend/`
Save your trained classifier as a `.joblib` file (for Logistic Regression / XGBoost) or `.pt` (PyTorch):
```bash
# Example
backend/models/classifier.joblib
```

### Step 2: Update the hook in `backend/model_service.py`
Open [`backend/model_service.py`](backend/model_service.py) and update the `load_model` method:

```python
# In backend/model_service.py -> DomainClassifierService.load_model()
import joblib

def load_model(self):
    self.model = joblib.load("models/classifier.joblib")
    print("Custom model loaded successfully!")
```

For real SPECTER2 transformer embeddings, install Hugging Face transformers:
```bash
pip install transformers torch
```
The service will automatically detect `transformers` and compute true 768-d embeddings using `allenai/specter2`.

---

## 🌟 Key Features

1. **PDF Drag & Drop Ingestion**: Upload any academic research PDF (arXiv, IEEE, ACM, Springer, Nature).
2. **Instant Benchmark Paper Selector**: 1-click test famous papers without needing local PDFs.
3. **Calibrated Confidence Gauge**: Visualizes raw logit confidence vs. temperature-scaled probability (ECE < 0.02).
4. **SPECTER2 2D Latent Space Map**: Interactive scatter manifold displaying current paper coordinates relative to domain centroids.
5. **Multi-Label Rankings**: Breakdown of primary and secondary categories (e.g. `cs.CL`, `cs.LG`, `stat.ML`).
6. **Human Review Dashboard**: Automatically flags low-confidence papers (< 70%) for expert human verification, saving ground-truth labels to `retraining_dataset.jsonl` for MLOps retraining.
7. **Batch Ingestion Queue**: Process multiple research papers simultaneously and export CSV / JSON reports.
8. **Interactive Architecture Explorer**: Visual interactive map of every stage in the pipeline with code inspection hooks.
