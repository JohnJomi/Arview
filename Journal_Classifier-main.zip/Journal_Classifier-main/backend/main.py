"""
FastAPI Server for SPECTER-Net Journal Classifier.
Exposes endpoints for PDF ingestion, SPECTER2 vectorization, multi-label domain inference,
and human review dataset logging.
"""

import os
import json
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from pdf_extractor import extract_paper_content_from_pdf
from model_service import SPECTER2EmbeddingService, DomainClassifierService

app = FastAPI(
    title="SPECTER-Net Journal Classifier API",
    description="Research paper classification via SPECTER2 embeddings and calibrated multi-label domain classifier",
    version="1.0.0"
)

# Enable CORS for frontend development
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize services
embedding_service = SPECTER2EmbeddingService()
classifier_service = DomainClassifierService()

# Ensure feedback storage directory exists
FEEDBACK_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(FEEDBACK_DIR, exist_ok=True)
FEEDBACK_FILE = os.path.join(FEEDBACK_DIR, "retraining_dataset.jsonl")


class FeedbackPayload(BaseModel):
    paperId: str
    title: str
    modelPredictedCategory: str
    modelConfidence: float
    humanValidatedCategory: str
    secondaryCategories: list[str] = []
    verdict: str
    reviewerNotes: Optional[str] = ""
    reviewedAt: str
    status: str = "labeled_for_retraining"


@app.get("/api/health")
def health_check():
    """Health check and model registry status."""
    return {
        "status": "healthy",
        "service": "SPECTER-Net Journal Classifier",
        "specter2_loaded": embedding_service.is_loaded,
        "classifier_loaded": classifier_service.model is not None,
        "taxonomy_classes": len(classifier_service.TAXONOMY),
        "calibration": "Temperature Scaling (T=1.15)"
    }


@app.post("/api/classify")
async def classify_paper(
    file: Optional[UploadFile] = File(None),
    text: Optional[str] = Form(None),
    title: Optional[str] = Form(None)
):
    """
    Ingests research paper (PDF or text) and returns calibrated multi-label classifications.
    """
    if not file and not text:
        raise HTTPException(status_code=400, detail="Either a PDF file or text content must be provided.")

    # 1. Paper Ingestion & Extraction
    if file:
        content_bytes = await file.read()
        extracted = extract_paper_content_from_pdf(content_bytes, filename=file.filename)
    else:
        extracted = {
            "title": title or "Manual Research Input",
            "abstract": text,
            "full_text": text,
            "page_count": 1,
            "word_count": len(text.split()),
            "authors": ["Researcher"],
            "doi": "10.48550/arXiv.manual",
            "venue": "Research Submission",
            "year": 2024
        }

    # 2. SPECTER2 Vector Embedding
    embedding_768d = embedding_service.encode(
        title=extracted["title"],
        abstract=extracted["abstract"]
    )

    # 3. Domain Classifier & Confidence Calibration
    classification = classifier_service.predict(
        embedding_768d=embedding_768d,
        text=extracted["abstract"] + " " + extracted["title"]
    )

    # 4. Structured Results Output
    return {
        "id": f"paper-{file.filename if file else 'manual'}",
        "title": extracted["title"],
        "authors": extracted["authors"],
        "affiliations": ["Research Institution / Laboratory"],
        "abstract": extracted["abstract"],
        "keywords": [
            classification["predictions"][0]["name"],
            "SPECTER2 Embedding",
            "Domain Classification",
            extracted["venue"]
        ],
        "venue": extracted["venue"],
        "year": extracted["year"],
        "doi": extracted["doi"],
        "pageCount": extracted["page_count"],
        "wordCount": extracted["word_count"],
        "primaryCategory": classification["primaryCategory"],
        "isLowConfidence": classification["isLowConfidence"],
        "calibration": classification["calibration"],
        "predictions": classification["predictions"],
        "embeddingPreview": classification["embeddingPreview"]
    }


@app.post("/api/feedback")
def submit_feedback(feedback: FeedbackPayload):
    """
    Logs human review corrections to the retraining dataset.
    """
    with open(FEEDBACK_FILE, "a", encoding="utf-8") as f:
        f.write(feedback.model_dump_json() + "\n")

    return {
        "status": "success",
        "message": "Human review correction appended to retraining dataset.",
        "record": feedback.model_dump()
    }


@app.get("/api/categories")
def get_categories():
    """Returns available domain categories."""
    return classifier_service.TAXONOMY


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
