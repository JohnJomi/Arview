"""
Test script for verifying backend extraction and classification logic locally.
"""
from model_service import SPECTER2EmbeddingService, DomainClassifierService
from pdf_extractor import extract_paper_content_from_pdf

def run_local_test():
    print("1. Initializing SPECTER2 Service...")
    embedder = SPECTER2EmbeddingService()
    
    sample_title = "Attention Is All You Need"
    sample_abstract = "The dominant sequence transduction models are based on complex recurrent or convolutional neural networks. We propose the Transformer, based solely on attention mechanisms."
    
    print("2. Generating embedding...")
    vec = embedder.encode(sample_title, sample_abstract)
    print(f"   Embedding generated: shape={vec.shape}, norm={float(round(sum(vec**2)**0.5, 3))}")
    assert len(vec) == 768, "Expected 768-d embedding"

    print("3. Initializing Classifier Service...")
    classifier = DomainClassifierService()
    
    print("4. Running prediction & calibration...")
    output = classifier.predict(vec, sample_title + " " + sample_abstract)
    print(f"   Primary Category: {output['primaryCategory']}")
    print(f"   Confidence: {output['calibration']['calibratedConfidence'] * 100:.1f}%")
    print(f"   Top 3 predictions: {[p['id'] + ': ' + str(round(p['calibratedScore']*100, 1)) + '%' for p in output['predictions'][:3]]}")
    
    print("All backend components verified successfully!")

if __name__ == "__main__":
    run_local_test()
